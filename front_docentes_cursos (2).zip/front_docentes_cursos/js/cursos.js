function cargarCursos(){
    var tableBody = $('#cursos-table tbody');
    $.ajax({
        url: 'http://localhost:8081/cursos',
        method: 'GET',
        success: function(data) {
            $.each(data, function(index, curso) {
                obtenerNombreDocente(curso.codDocente, function(nombreDocente) {
                    var row = $('<tr>');
                    row.append($('<td>').text(curso.cod));
                    row.append($('<td>').text(curso.nombre));
                    row.append($('<td>').text(nombreDocente)); 
                    row.append($('<td>').html('<a href="../../index/modificar/modCurso.html?cod=' + curso.cod + '" class="edit-link">Modificar</a>'));
                    row.append($('<td>').html('<a href="../../index/eliminar/eliminarCurso.html?cod=' + curso.cod + '" class="edit-link">Eliminar</a>'));
                    tableBody.append(row);
                    
                });
            });
        },
        error: function(error) {
            console.error('Error:', error);
        }
    });
    cargarDocentes();
}
cargarCursos();
function obtenerNombreDocente(codDocente, callback) {
    $.ajax({
        url: `http://localhost:8081/docentes/${codDocente}`,
        method: 'get',
        success: function(response) {
            callback(response.nombre);
        },
    });
}
function cargarDocentes() {
    $.ajax({
        url: 'http://localhost:8081/docentes',
        method: 'GET',
        success: function(data) {
            var selectDocente = $('#docente');
            selectDocente.empty();
            $.each(data, function(index, docente) {
                selectDocente.append($('<option>').text(docente.nombre).val(docente.cod));
            });
        },
        error: function(error) {
            console.error('Error al cargar los docentes:', error);
        }
    });
}
function registrarCurso(event) {
    event.preventDefault();

    var cod = $('#codigo').val();
    var nombre = $('#nombre').val();
    var docente = $('#docente').val();

    $.ajax({
        url: "http://localhost:8081/cursos",
        method: 'post',
        data: { cod: cod, nombre: nombre, codDocente: docente },
    }).done((response) => {
        console.log(response);
        mostrarMensaje('mensajeExito', 'Curso registrado exitosamente!');
    }).fail((err) => {
        console.error(err);
        mostrarMensaje('mensajeError', 'Error: Este código ya existe. Por favor, elija otro.');
    });
}
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
function modificarCurso(event) {
    event.preventDefault();

    var cod = $('#codigo').val();
    var nombre = $('#nombre').val();
    var docente = $('#docente').val();
    var codigoCurso = getParameterByName('cod');
    $('#codigo').val(codigoCurso);

    $.ajax({
        url: `http://localhost:8081/cursos/${codigoCurso}`,
        method: 'put',
        data: { cod: cod, nombre: nombre, codDocente: docente },
    }).done((response) => {
        console.log(response);
        mostrarMensaje('mensajeExito', 'Curso modificado exitosamente!');
    }).fail((err) => {
        console.error(err);
        mostrarMensaje('mensajeError', 'Error: Este código ya existe. Por favor, elija otro.');
    });
}

function mostrarMensaje(elementoId, mensaje) {
    $('#' + elementoId).text(mensaje);
    setTimeout(function() {
        $('#' + elementoId).text('');
    }, 5000);
}

function eliminarCurso(event) {
    event.preventDefault();
    var codigoCurso = getParameterByName('cod');
    console.log(codigoCurso)
    $.ajax({
        url: `http://localhost:8081/cursos/${codigoCurso}`,
        method: 'delete',
    }).done((response) => {
        console.log(response);
        mostrarMensaje('mensajeExito', 'Curso eliminado exitosamente!');
    }).fail((err) => {
        console.error(err);
        mostrarMensaje('mensajeError', 'Error: Este código ya existe. Por favor, elija otro.');
    });
}


function cargarDatos(){
    var codigoCurso = getParameterByName('cod');
    $('#codigo').val(codigoCurso);
    $(document).ready(function () {
        $.ajax({
        url: `http://localhost:8081/cursos/${codigoCurso}`,
        method: 'GET',
        success: function(data) {
            var curso = data;
            obtenerNombreDocente(curso.codDocente, function(nombreDocente) {
                $('#nombre').val(curso.nombre);
                $('#docente option:contains(' + nombreDocente + ')').prop('selected', true);
            });
        },
        error: function(error) {
            console.error('Error:', error);
    }
});
});
}
cargarDatos();
