$(document).ready(function() {
    // Obtener la referencia a la tabla
    var tableBody = $('#docentes-table tbody');

    // Hacer la petición para obtener la lista de docentes
    $.ajax({
        url: 'http://localhost:8081/docentes',
   method: 'GET',
        dataType: 'json',
        success: function(data) {
            // Iterar sobre los docentes y agregar filas a la tabla
            $.each(data, function(index, docente) {
                var row = $('<tr>');
                row.append($('<td>').text(docente.cod));
                row.append($('<td>').text(docente.nombre));
                row.append($('<td>').text(docente.idOcupacion));

                // Agregar más celdas según tus datos

                tableBody.append(row);
            });
        },
        error: function(error) {
            console.error('Error:', error);
        }
    });
});
function mostrarCursos(cursos) {
    var tableBody = document.getElementById('cursosBody');
    tableBody.innerHTML = '';

    cursos.forEach(curso => {
        obtenerNombreDocente(curso.docente, function (nombreDocente) {
            var row = document.createElement('tr');
            row.innerHTML = `<td>${curso.id}</td><td>${curso.nombre}</td><td>${nombreDocente}</td><td><a href="#" class="button editar" data-id="${curso.id}">Editar</a> | <a href="#" class="button eliminar" data-codigo="${curso.id}">Eliminar</a></td>`;
            tableBody.appendChild(row);
        });
    });
}

function obtenerNombreDocente(idDocente, callback) {
    $.ajax({
        url: `http://localhost:8081/docentes/${idDocente}`,
        method: 'get',
        dataType: 'json',
        success: function (response) {
            callback(response.nombre);
        },
    });
}
