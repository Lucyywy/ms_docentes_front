$(document).ready(function() {
    // Obtener la referencia a la tabla
    var tableBody = $('#cursos-table tbody');

    // Hacer la petición para obtener la lista de docentes
    $.ajax({
        url: 'http://localhost:8081/cursos',
   method: 'GET',
        dataType: 'json',
        success: function(data) {
            // Iterar sobre los docentes y agregar filas a la tabla
            $.each(data, function(index, curso) {
                var row = $('<tr>');
                row.append($('<td>').text(curso.cod));
                row.append($('<td>').text(curso.nombre));
                row.append($('<td>').text(curso.codDocente));
                // Agregar más celdas según tus datos

                tableBody.append(row);
            });
        },
        error: function(error) {
            console.error('Error:', error);
        }
    });
});
